# Unified Gasifier Simulator

A modern, educational React-based gasifier simulator combining ideal and realistic performance models. Built for testing on GitHub Pages before deployment to homegasifier.com.

## What's Included

**Core Files:**
- `unified-gasifier-simulator.jsx` — Main React component with all calculations and UI
- `main.jsx` — React entry point
- `index.html` — HTML template
- `package.json` — Dependencies and npm scripts
- `vite.config.js` — Vite build configuration
- `.gitignore` — Git exclusions

**Deployment:**
- `deploy.yml` — GitHub Actions workflow for automatic builds

**Documentation:**
- `SETUP_GUIDE.md` — Step-by-step setup and deployment instructions
- `README.md` — This file

## Features

### Two Performance Modes
1. **Ideal Performance**: Energy balance without downstream component losses
2. **Realistic Performance**: Includes cooler efficiency, filter pressure drop, tar cracker effectiveness, and system radiation losses

### Four Input Tabs
1. **Reactor**: Dimensions, fuel type, moisture content
2. **Operating Conditions**: Equivalence ratio, air temperature
3. **Downstream**: Cooler, filter, tar cracker options
4. **Results**: All outputs with 3D visualization (optional)

### Comprehensive Outputs
- Mass flows (feedrate, air, gas in lbm/hr and cfm)
- Temperatures (reactor, gas exit in °F)
- Energy (fuel input, total input, heat removal in Btu/hr)
- Cold Gas Efficiency (%)
- Syngas composition (CO, H₂, CO₂, CH₄, N₂ in % vol)
- Tar content (g/Nm³)
- System performance (pressure drop, hearth load, velocity)

### US Customary Units Only
All inputs and outputs use inches, lbm/hr, Btu/hr, °F, cfm, etc. — no metric conversions.

## Quick Start

### 1. Clone or Copy to Your GitHub Repo
```bash
git clone https://github.com/[YOUR_USERNAME]/gasifier-simulator.git
cd gasifier-simulator
```

### 2. Install & Run Locally
```bash
npm install
npm run dev
```
Open `http://localhost:5173` in your browser

### 3. Deploy to GitHub Pages
```bash
npm run build
npm run deploy
```
Your simulator will be live at: `https://[YOUR_USERNAME].github.io/gasifier-simulator/`

See `SETUP_GUIDE.md` for detailed instructions.

## Calculation Engine

### Cold Gas Efficiency
```
CGE = (Total Energy Input - Heat Removed) / Total Energy Input × 100%
```

**Ideal mode**: CGE = (Energy - Cooler Heat) / Energy
**Realistic mode**: CGE = Ideal - Tar Cracker Loss - Filter Loss - System Radiation

### Syngas Composition (Empirical)
Based on equivalence ratio (ER):
- CO increases with higher ER
- H₂ increases with higher ER
- CO₂ decreases with higher ER
- CH₄ marginal contribution

> **Note**: These are empirical approximations based on fuel type and ER. Validate against measured gas analyzer data.

### Tar Model
```
Tar = 50 + (ER - 0.25) × 200 g/Nm³
If cracker enabled: Tar × 0.3 (70% reduction)
```

### Reactor Temperature
```
T = 1200 + (ER - 0.25) × 400 °F
Range: 600–1800°F
```

## What's Validated

✓ Stoichiometry (STOICH_AIR = 6.2 lbm/lbm)
✓ Efficiency formula structure (based on Chandra & Payne 1986)
✓ Temperature vs ER trends (qualitative)
✓ Output ranges (75–95% CGE achievable)

## What's NOT Validated

✗ Syngas composition (empirical model, no measured reference)
✗ Tar yields (empirical model, needs tar trap data)
✗ Downdraft-specific behavior (validation paper is updraft)
✗ System scale effects (assumes consistent across sizes)

## Next: Real-World Validation

To improve accuracy:

1. **Collect syngas data**
   - Use gas analyzer (Orsat or online analyzer)
   - Measure CO, H₂, CO₂, CH₄, N₂
   - Test at multiple ER and fuel moisture levels

2. **Collect tar data**
   - Use tar trap system
   - Weigh tar samples at each test condition
   - Compare to simulator output

3. **Compare predictions**
   - Run simulator with exact test conditions
   - Calculate % difference vs measured
   - Document accuracy range

4. **Iterate**
   - Adjust empirical constants if needed
   - Refine loss models based on findings
   - Target: ±15% accuracy (following Chandra & Payne standard)

## Project Structure

```
gasifier-simulator/
├── unified-gasifier-simulator.jsx      # Main React component
├── main.jsx                             # Entry point
├── index.html                           # HTML template
├── package.json                         # Dependencies
├── vite.config.js                       # Build config
├── .gitignore                           # Git exclusions
├── deploy.yml                           # GitHub Actions workflow
├── SETUP_GUIDE.md                       # Detailed setup instructions
└── README.md                            # This file

dist/                                   # Build output (generated)
node_modules/                           # Dependencies (generated)
```

## Customization

### Change Styling
Edit CSS variables in `unified-gasifier-simulator.jsx`:
```javascript
--bg: #0f1419;
--accent: #fbbf24;
--green: #10b981;
// etc.
```

### Add New Inputs
1. Add state: `const [newParam, setNewParam] = useState(default);`
2. Add ControlGroup or select in appropriate tab
3. Use in `calculatePerformance()` function

### Modify Calculations
All calculation logic is in `calculatePerformance()` function. Change formulas, constants, or loss models as needed.

### Change GitHub Pages URL
In `package.json`: `"homepage": "https://your-username.github.io/your-repo/"`
In `vite.config.js`: `base: '/your-repo/',`

## Troubleshooting

**Port already in use?**
```bash
npm run dev -- --port 3000
```

**Deploy fails?**
- Check Node version: `node --version` (needs 18+)
- Reinstall: `rm -rf node_modules package-lock.json && npm install`
- Check GitHub Pages is enabled in repo settings

**Changes not showing on GitHub Pages?**
- Wait 1–2 minutes for deployment
- Clear browser cache
- Check dist/ folder was generated: `npm run build`

## Dependencies

- React 18.2
- Three.js r128 (3D visualization)
- Vite 5 (build tool)
- gh-pages (GitHub Pages deploy)

## License

Educational use. Reference and cite Chandra & Payne (1986) for thermal efficiency validation.

---

**Ready to test?** See `SETUP_GUIDE.md` for step-by-step instructions.

**Questions?** Check the homegasifier.com documentation or the embedded tooltips in the simulator.
